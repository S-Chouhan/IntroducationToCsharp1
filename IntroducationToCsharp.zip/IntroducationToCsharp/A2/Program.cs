﻿using System;
using System.Linq;

using System.Collections.Generic;
using System.Collections;
using System.Collections.ObjectModel;


//namespace A2
//{
//public class Program
//{
//    // Parameterised Constructor
//    //private string _firstname;

//    //private string _lastname;

//    //public Program(string firstname, string lastname)
//    //{
//    //    this._firstname = firstname;
//    //    this._lastname = lastname;
//    //}

//    ////make the parmaterised constructor, non parmatarised constructor and get acces.
//    //public Program()
//    //    : this("no", "name")
//    //{
//    //}

//    //public void printFullname()
//    //{
//    //    Console.WriteLine("Full name ={0}", this._firstname + " " + this._lastname);
//    //}

//    //  static void Main(string[] args)
//    //{
//    //Console.WriteLine(Class1.Getname1());
//    //Console.ReadLine();

//    // While loop here
//    //Do while loop
//    //    string userchoice = string.Empty;
//    //    do
//    //    {
//    //        Console.WriteLine("Please enter the number");
//    //        int x = int.Parse(Console.ReadLine());
//    //        int start = 0;
//    //        while (start <= x)
//    //        {
//    //            Console.Write("start = {0} ", start);
//    //            start += 2;

//    //        }
//    //        do
//    //        {
//    //            Console.WriteLine("Do you want to continue - YES or NO");
//    //            userchoice = Console.ReadLine().ToUpper();
//    //            if (userchoice != "YES" && userchoice != "NO")
//    //            {
//    //                Console.WriteLine("Please enter the correct option");
//    //            }
//    //        } while (userchoice != "YES" && userchoice != "NO");

//    //    } while (userchoice == "YES");

//    // Simple example for do while
//    //int x = 10;
//    //int userInput =0;
//    //do{
//    //    Console.WriteLine("enter then number");
//    //    userInput= int.Parse(Console.ReadLine());

//    //}while(x==userInput);

//    //Out Parmeter

//    //int catchSum, catchProduct;
//    //calculuate(3, 2, out catchSum, out catchProduct);
//    //Console.WriteLine(catchSum);
//    //Console.WriteLine(catchProduct);
//    //Console.ReadLine();

//    // int[] varia = new int[3];
//    // varia[0]=1;
//    // varia[1]=2;
//    // varia[2]=3;

//    //// arraypameter();
//    // //arraypameter(varia);
//    //arraypameter(1, 2, 1, 1, 1);
//    //Console.ReadLine();
//}

////Out Parmeter
//    public static void calculuate(int x , int y, out int sum , out int product){
//        sum = x + y;
//        product = x * y;
//    }

//Params Parameter
//public static void arraypameter(params int[] x)
////{
//    Console.WriteLine("Total number of elements are {0}",x.Length);
//    foreach (int i in x)
//    {
//        Console.WriteLine(i);
//    }
//}

//Constructor

///Program obj1 = new Program("santosh", "chavan");

//  }
//}

// Regarding constructor and constructor overloading
//public class customer
//{
//    public static void Main()
//    {
//        Program obj = new Program("santosh","chavan");
//        obj.printFullname();
//        //this is called constructor overloading
//        Program obj2 = new Program();
//        obj2.printFullname();
//        Console.ReadLine();

//    }

//}

//static variable and static constructor
//static constructor loads before the instance constructor loads and sttic constructor consumes less memory coz it only get calls only once

//public class circle{
//    static float _pi ;
//    int _radius;
//    static circle()
//    {
//        Console.WriteLine("static constructor");
//        _pi = 3.14F;
//    }
//    public circle(int radius)
//    {
//        Console.WriteLine("instance constructor");
//        this._radius = radius;
//    }
//    public float claculateArea()
//    {
//        return this._radius * circle._pi * 2;

//    }

// }

//public class program
//{
//    public static void Main()
//    {
//        circle obj = new circle(2);
//       float area = obj.claculateArea();
//       Console.WriteLine("Area = {0} ", area);

//       circle obj2 = new circle(22);
//       float area2 = obj2.claculateArea();
//       Console.WriteLine("Area = {0} ", area2);
//       Console.ReadLine();

//    }

//}

//Inheritance

//public class parent
//{
//    public parent()
//    {
//        Console.WriteLine("parent class");

//    }

//    public parent(string cla)
//    {
//        Console.WriteLine(cla);

//    }
//    public parent(string cla, int y)
//    {
//        Console.WriteLine(cla +""+y);

//    }

//    public void fullname()
//    {
//        Console.WriteLine("hello this parent method");
//    }

//}

//public class child :parent
//{
//    //base is used to select parent construcotr you want to call when you excute child class
//    public child():base("base key used to call second constrcutor of parent class")
//    {
//        Console.WriteLine("this is child class");

//    }

//    //Another way of using base keyword
//    public child(string x)
//        : base(x)
//    {
//    }

//      // If you intended to hide method of the parent, use new keyword.
//    public new void fullname()
//    {
//        // base keyword is used to call parent class memebers
//      //  base.fullname();
//        Console.WriteLine("hello this child method");
//    }
//}
//public class progrma
//{
//    static void Main()
//    {
//        child obj = new child();
//        //By using type casting you can even call the parent class memebers
//        //  ((parent)obj).fullname();

//        //Even by using obj of the parent, by using child constructor
//        parent obj2 = new child();
//        obj2.fullname();

//        Console.ReadLine();

//    }
//}

//Polymorphism: It enables you to invoke drived class method through base class reference variable at runtime.

//public class Employee
//{
//   public string fname = "hello";
//   public string lname = "santohs";

//    public virtual void fullname()
//    {
//        Console.WriteLine(fname+" "+lname);
//    }

//}

//public class PartimeEmployee : Employee
//{
//    public override void fullname()
//    {
//        Console.WriteLine(fname + " " + lname +" - part time");
//    }

//}
//public class FullimeEmployee : Employee
//{
//    public override void fullname()
//    {
//        Console.WriteLine(fname + " " + lname +" - full time");
//    }
//}

//public class temprorary : Employee
//{
//    public override void fullname()
//    {
//        Console.WriteLine(fname + " " + lname + " - temprory");
//    }

//}

//public class program
//{
//    static void Main()
//    {
//        Employee[] obj = new Employee[4];
//        obj[0] = new Employee();
//        obj[1] = new PartimeEmployee();
//        obj[2] = new FullimeEmployee();
//        obj[3] = new temprorary();

//        foreach (Employee e in obj)
//        {
//            e.fullname();
//        }
//        Console.ReadLine();

//    }
//}

//Difference between Method overriding and metho hidding

//public class parent
//{
//    public virtual void fullname()
//    {
//        Console.WriteLine("this is the parent method");
//    }
//}

//public class child : parent
//{
//    public override void fullname()
//    {
//        Console.WriteLine("this is the child mehtod");
//    }
//}

//public class program
//{
//    private static void Main()
//    {
//        parent obj = new child();
//        obj.fullname();
//        Console.ReadLine();
//    }
//}

//Properties

// getter and setter Methods, will see properties in the next code
//public class student
//{
//    private int _studentid;
//    private string _studentName;
//    private int _studentMarks = 35;

//    public int getpassMark()
//    {
//        return _studentMarks;
//    }

//    public void setId(int id)
//    {
//        if (id < 0)
//        {
//            throw new Exception("please enter greater then zero vlaue");
//        }
//        _studentid = id;
//    }

//    public int getID()
//    {
//        return this._studentid;
//    }

//    public void setName(string name)
//    {
//        if (string.IsNullOrEmpty(name))
//        {
//            throw new Exception("please enter name ");
//        }
//        _studentName = name;
//    }

//    public string getName()
//    {
//        return string.IsNullOrEmpty(this._studentName) ? "no name" : this._studentName;
//    }
//}

//public class program
//{
//    private static void Main()
//    {
//        student obj = new student();
//        obj.setId(101);
//        obj.setName("sam");

//        Console.WriteLine("Id={0},Name={1},Marks={2}", obj.getID(),obj.getName(),obj.getpassMark());
//        Console.ReadLine();
//    }
//}

//properties

//public class student
//{
//    private int _studentid;
//    private string _studentName;
//    private int _studentMarks = 35;

//    //Auto Implement properties doesnot need private variables, it will create on own at compile time

//    public string city { get; set; }
//    public int age { get; set; }

//    public int Mark
//    {
//        get{
//        return _studentMarks;
//    }
//    }
//    public int Id
//    {
//        set
//        {
//            if (value < 0)
//            {
//                throw new Exception("please enter greater then zero vlaue");
//            }
//            _studentid = value;
//        }
//        get
//        {
//            return this._studentid;
//        }
//    }

//    public int getID()
//    {
//        return this._studentid;
//    }

//    public string Name
//    {
//     get{
//         return string.IsNullOrEmpty(this._studentName) ? "no name" : this._studentName;
//     }
//        set{
//            if (string.IsNullOrEmpty(value))
//            {
//                throw new Exception("please enter name ");
//            }
//            _studentName = value;
//        }

//    }

//}

//public class program
//{
//    private static void Main()
//    {
//        student obj = new student();
//        obj.Id = 101;
//        obj.Name = "santosh";
//        obj.city = "hyderabad";
//        obj.age = 21;

//        Console.WriteLine("Id={0},Name={1},Marks={2},City={3},Age={4}", obj.Id, obj.Name, obj.Mark,obj.city,obj.age);
//        Console.ReadLine();
//    }
//}

//Structs

//public struct student
//{
//    private int _studentId;
//    private string _studentName;

//    public student(int Id, string name1)
//    {
//        this._studentId = Id;
//        this._studentName = name1;

//    }
//    public int StudentId
//    {
//        get { return _studentId; }
//        set { _studentId = value; }
//    }

//    public string StudentName
//    {
//        get { return _studentName; }
//        set { _studentName = value; }
//    }

//    public void fullname()
//    {
//        Console.WriteLine("name={0},id={1}",this._studentName,this._studentId);
//    }

//}
//public class program{
//    public static void Main()
//    {
//        //0
//        student obj0 = new student(1, "kan");
//        obj0.fullname();
//        //1
//        student obj = new student();
//        obj.StudentId = 101;
//        obj.StudentName = "santosh";
//        obj.fullname();
//        //2
//        student obj2 = new student {
//        StudentId=21,
//        StudentName="rhaul"
//                };
//        obj2.fullname();
//        Console.ReadLine();

//    }

//}

//Interfaces

//internal interface Icustomer
//{
//    void Print();
//}

//internal interface Icustomer2 : Icustomer
//{
//    void Print2();
//}

//public class customer : Icustomer2
//{
//    public void Print()
//    {
//        Console.WriteLine("interface 1");
//    }

//    public void Print2()
//    {
//        Console.WriteLine("interface 2");
//    }
//}

//public class program
//{
//    public static void Main()
//    {
//        //customer obj = new customer();
//        //obj.Print();
//        //obj.Print2();

//        Icustomer parentInterface = new customer();
//        parentInterface.Print();
//        Console.ReadLine();
//    }
//}

//Explict Interfaces

//interface Icustomer1
//{
//    void Print1();
//}

//interface Icustomer2
//{
//    void Print1();
//}

//public class customer : Icustomer1,Icustomer2
//{
//    //Normal Interface or implict interface
//    //public void Print1()
//    //{
//    //    Console.WriteLine("Interface 1 is called");
//    //}

//    //Explict Interface, remove public and add interface name and then interface method name

//    void Icustomer1.Print1()
//    {
//        Console.WriteLine("Interface 1 is called");
//    }

//    void Icustomer2.Print1()
//    {
//        Console.WriteLine("Interface 2 is called");
//    }

//    // Defualt Interface
//    //public void Print1()
//    //{
//    //    Console.WriteLine("Interface 1 is called");
//    //}
//}

//public class someth
//{
//    static void Main()
//    {
//        //customer obj = new customer();
//        ////Now with the help obj variable you can't call the Explicit interface
//        ////obj.Print1();

//        ////Now here your typecasting this obj variable in to interface variable below, by using interface variable you call the explicit methods
//        //((Icustomer1)obj).Print1();
//        //((Icustomer2)obj).Print1();
//        //Console.ReadLine();

//        //Another way is

//        Icustomer1 Ic1 = new customer();
//        Icustomer2 Ic2 = new customer();
//        Ic1.Print1();
//        Ic2.Print1();
//        Console.ReadLine();

//    }
//}

//// Abstract classes

//public abstract class Abas1
//{
//    public abstract void customer();

//}

//public class checkabastract : Abas1
//{
//    public override void customer()
//    {
//        Console.WriteLine("heloo worl");
//    }
//}

//public class pro
//{
//    public static void Main()
//    {
//        Abas1 obj = new checkabastract();
//        obj.customer();
//        Console.ReadLine();

//    }
//}

// multipile classes inheritance using interfaces

//interface IA
//{
//    void MA();
//}

//interface IB
//{
//    void MB();
//}

//public class A:IA
//{
//    public void MA() {
//        Console.WriteLine("hello first class");
//    }

//}

//public class B: IB
//{
//    public void MB()
//    {
//        Console.WriteLine("hello second class");
//    }

//}

//public class AB : IA, IB
//{
//    A objA = new A();
//    B objB = new B();

//    public void MA()
//    {
//        objA.MA();
//    }

//    public void MB()
//    {
//        objB.MB();
//    }

//}

//public class program
//{
//    public static void Main()
//    {
//        AB objAB = new AB();
//        objAB.MA();
//        objAB.MB();
//        Console.ReadLine();
//    }

//

// Delegates : A delgate is a type safe function pointer

//public delegate void myDelegate(string message);

//public class program
//{
//    public  static void hello(string message)
//    {
//        Console.WriteLine(message);
//    }

//    public static void Main()
//    {
//        // one way to call
//        //myDelegate delegateObj = new myDelegate(hello);

//        //delegateObj("hello world");

//        //another way to call
//        hello("hellos orld");
//        Console.ReadLine();
//    }

//}

//List adding values in different way
//public class employee
//{
//    public int empid { get; set; }
//    public string empname { get; set; }
//    public int empsalary { get; set; }
//    public int empexperience { get; set; }

//    public static void PropmetedEmployee(List<employee> emplist)
//    {
//        foreach (employee e in emplist)
//        {
//            if (e.empexperience >= 5)
//            {
//                Console.WriteLine(e.empname + " Promoted");
//            }
//        }
//    }
//}

//public class progrma
//{
//    public static void Main()
//    {
//        List<employee> obj = new List<employee>() {
//        new employee(){empid=101,empname="santosh",empsalary=9000,empexperience=12},
//        new employee(){empid=102,empname="rahul",empsalary=4000,empexperience=2},
//        };

//        obj.Add(new employee() { empid = 103, empname = "kare", empexperience = 21, empsalary = 12111 });
//        obj.Add(new employee() { empid = 104, empname = "ram", empexperience = 1, empsalary = 99111 });

//        employee objEmp = new employee { empid = 105, empname = "kathil", empsalary = 3002, empexperience = 5 };
//        obj.Add(objEmp);

//        employee objemp1 = new employee();
//        objemp1.empid = 106;
//        objemp1.empname = "SHUR";
//        objemp1.empsalary = 9211;
//        objemp1.empexperience = 8;
//        obj.Add(objemp1);

//        employee.PropmetedEmployee(obj);
//        Console.ReadLine();

//    }

//}

//use delegates as functions

//public delegate bool ispromoted(employee isemp);

//public class employee
//{
//    public int empid { get; set; }
//    public string empname { get; set; }
//    public int empsalary { get; set; }
//    public int empexperience { get; set; }

//    public static void PropmetedEmployee(List<employee> emplist, ispromoted ispromotal)
//    {
//        foreach(employee e in emplist)
//        {
//            if (ispromotal(e))
//            {
//                Console.WriteLine(e.empname + " Promoted");
//            }
//        }
//    }
//}

//public class progrma
//{
//    public static bool promote(employee emp)
//    {
//        if (emp.empexperience >= 5)
//        {
//            return true;
//        }
//        else
//        {
//            return false;
//        }
//    }
//    public static void Main()
//    {
//        List<employee> obj = new List<employee>() {
//        new employee(){empid=101,empname="santosh",empsalary=9000,empexperience=12},
//        new employee(){empid=102,empname="rahul",empsalary=4000,empexperience=2},
//        };

//        obj.Add(new employee() { empid = 103, empname = "kare", empexperience = 21, empsalary = 12111 });
//        obj.Add(new employee() { empid = 104, empname = "ram", empexperience = 1, empsalary = 99111 });

//        employee objEmp = new employee { empid = 105, empname = "kathil", empsalary = 3002, empexperience = 5 };
//        obj.Add(objEmp);

//        employee objemp1 = new employee();
//        objemp1.empid = 106;
//        objemp1.empname = "SHUR";
//        objemp1.empsalary = 9211;
//        objemp1.empexperience = 8;
//        obj.Add(objemp1);

//        ispromoted ispromotable = new ispromoted(promote);

//        employee.PropmetedEmployee(obj,ispromotable);
//        Console.ReadLine();

//    }

//}

////Using lambada expression

//public delegate bool ispromoted(employee isemp);

//public class employee
//{
//    public int empid { get; set; }
//    public string empname { get; set; }
//    public int empsalary { get; set; }
//    public int empexperience { get; set; }

//    public static void PropmetedEmployee(List<employee> emplist, ispromoted ispromotal)
//    {
//        foreach (employee e in emplist)
//        {
//            if (ispromotal(e))
//            {
//                Console.WriteLine(e.empname + " Promoted");
//            }
//        }
//    }
//}

//public class progrma
//{
//    public static void Main()
//    {
//        List<employee> obj = new List<employee>() {
//        new employee(){empid=101,empname="santosh",empsalary=9000,empexperience=12},
//        new employee(){empid=102,empname="rahul",empsalary=4000,empexperience=2},
//        };

//        obj.Add(new employee() { empid = 103, empname = "kare", empexperience = 21, empsalary = 12111 });
//        obj.Add(new employee() { empid = 104, empname = "ram", empexperience = 1, empsalary = 99111 });

//        employee objEmp = new employee { empid = 105, empname = "kathil", empsalary = 3002, empexperience = 5 };
//        obj.Add(objEmp);

//        employee objemp1 = new employee();
//        objemp1.empid = 106;
//        objemp1.empname = "SHUR";
//        objemp1.empsalary = 9211;
//        objemp1.empexperience = 8;
//        obj.Add(objemp1);

//       employee.PropmetedEmployee(obj, emp=> emp.empexperience>=5);
//        Console.ReadLine();

//    }

//}

//MULTICASTE DELEGATE: A multicaste delegate is a delegate that has reference to more then one function

//public delegate void printanme();
//public class Customer
//{
//    static void Main()
//    {
//        printanme del1, del2, del3, del4;
//        del1 = new printanme(checkname1);
//        del2 = new printanme(checkname2);
//        del3 = new printanme(checkname3);
//        //this is the del4 is multicast delegeate coz
//        //It is pointing to all the 3 delegates
//        del4 = del1 + del2 + del3 - del2;
//        //By executing del4, we executing all other delegates
//        del4();
//    Console.ReadLine();
//    }

//    public static void checkname1()
//    {
//        Console.WriteLine("Hello your checking name with method-1");
//    }

//    public static void checkname2()
//    {
//        Console.WriteLine("Hello your checking name with method -2");
//    }
//    public static void checkname3()
//    {
//        Console.WriteLine("Hello your checking name with method -3");
//    }

//}

//Another Method using "+="
//Without creating different instances

//public delegate void printname();

//public class customer
//{
//    static void Main()
//    {
//    printname objdel = new printname(customer1);
//    objdel += customer2;
//    objdel += customer3;
//    objdel();
//        Console.ReadLine();

//    }

//    public static void customer1()
//    {
//        Console.WriteLine("hello method 1");
//    }
//    public static void customer2()
//    {
//        Console.WriteLine("hello method 1");
//    }
//    public static void customer3()
//    {
//        Console.WriteLine("hello method 1");
//    }

//}

//public delegate int intdelegate();

//public class customer
//{
//    public static int one1()
//    {
//        return 1;
//    }
//    public static int two2()
//    {
//        return 2;
//    }

//    static void Main()
//    {
//        intdelegate objdel = new intdelegate(one1);
//        objdel += two2;
//        int x = objdel();
//        Console.WriteLine("objdel = " + x);
//        Console.ReadLine();
//    }
//}

//public delegate void intdelegate(out int integer);

//public class customer
//{
//    public static void one1(out int x)
//    {
//        x = 1;
//    }
//    public static void two2(out int y)
//    {
//        y = 2;
//    }

//    static void Main()
//    {
//        intdelegate objdel = new intdelegate(one1);
//        objdel += two2;
//        int outdelegatevalue = -3;
//        objdel(out outdelegatevalue);
//        Console.WriteLine("objdel = " + outdelegatevalue);
//        Console.ReadLine();
//    }
//}

//Exception Handling

//ALt+CTRL+E to view all the exception in .NEt
//public class exceptoion
//{
//    public static void Main()
//    {
//        StreamReader sr = null;
//        try {
//         sr = new StreamReader(@"C:\Questio.txt");
//        Console.WriteLine(sr.ReadToEnd());

//        }

//            //specific exection comes first
//        catch (FileNotFoundException ex)
//        {
//            Console.WriteLine("File cheche the file {0} correctly",ex.FileName);

//        }

//        //genric exeception at last

//        catch (Exception ex)
//        {
//            Console.WriteLine(ex.Message);
//        }

//If there is any problem or exception in catch block, to overcome that problem we use finally block
//        finally
//        {
//        if(sr!=null){
//            sr.Close();
//        }
//        Console.WriteLine("finally blocked");
//        }
//        Console.ReadLine();
//    }

//}

//Inner Exception

//public class exceptoion
//{
//    public static void Main()
//    {
//        try
//        {
//            try
//            {
//                Console.WriteLine("please enter the first number");
//                int x = int.Parse(Console.ReadLine());
//                Console.WriteLine("please enter the second number");
//                int y = int.Parse(Console.ReadLine());
//                int z = x / y;
//                Console.WriteLine("Result is = {0}", z);
//            }
//            catch (Exception ex)
//            {
//                string filepath = @"D:\Log1.txt";
//                if (File.Exists(filepath))
//                {
//                    StreamWriter wr = new StreamWriter(filepath);
//                    wr.Write(ex.GetType().Name);
//                    wr.WriteLine();
//                    wr.Write(ex.Message);
//                    wr.Close();
//                    Console.WriteLine("There is a problem try again later");
//                }
//                else
//                {
//                    //Here "ex" is which takes the inner exception
//                    throw new FileNotFoundException(filepath + "is not present", ex);
//                }
//            }
//            Console.ReadLine();
//        }
//        catch (Exception exception)
//        {
//            Console.WriteLine(exception.GetType().Name+ "current exception");
//            //this is important, if you dont put this condition the system may get crash
//            if (exception.InnerException != null)
//            {
//                Console.WriteLine(exception.InnerException.GetType().Name + "inner exception");
//            }
//            Console.ReadLine();

//        }
//    }

//}

// Custom Exceptions

//public class customeexception
//{
//    static void Main()
//    {
//        throw new userAlreadyLoggedInException("hllo");
//    }
//}

//[Serializable]

//public class userAlreadyLoggedInException : Exception
//{
//    public userAlreadyLoggedInException()
//        : base()
//    { }
//    public userAlreadyLoggedInException(string message)
//        :base(message)
//    {
//    }

//    public userAlreadyLoggedInException(string message, Exception innerException)
//        : base(message, innerException)
//    {
//    }

//    public userAlreadyLoggedInException(SerializationInfo info, StreamingContext context):base(info,context)
//    {
//    }

//}

//Excetion handling to use in good way
//public class exec
//{
//    public static void Main()
//    {
//        try
//        {
//            Console.WriteLine("please enter the first number");
//            int firstno;
//            bool checkNumerator = int.TryParse(Console.ReadLine(), out firstno);
//            if (checkNumerator)
//            {
//                int secondno;
//                Console.WriteLine("please enter the second number");

//                bool checDenominator = int.TryParse(Console.ReadLine(), out secondno);
//                if (checDenominator && secondno != 0)
//                {
//                    int z = firstno / secondno;

//                    Console.WriteLine("Result is = {0}", z);
//                }
//                else
//                {
//                    if (secondno == 0)
//                    {
//                        Console.WriteLine("Denominator should not be 0");
//                    }
//                    else
//                    {
//                        Console.WriteLine("Numerator should ba a valued number between {0} and {1}", Int32.MinValue, Int32.MaxValue);
//                    }
//                }
//            }
//            else
//            {
//                Console.WriteLine("Numerator should ba a valued number between {0} and {1}", Int32.MinValue, Int32.MaxValue);
//            }
//        }
//        catch (Exception ex)
//        {
//            Console.WriteLine(ex.Message);
//        }
//        Console.ReadLine();
//    }
//}

//Enums

//0 - Unkown
//1-Male
////2-Female
//public class Customer
//{
//    public string Name{ get; set; }
//    public int gender { get; set; }
//}

//public class program1
//{
//    static void Main()
//    {
//        Customer[] obj = new Customer[3];

//        obj[0] = new Customer { Name = "Samtpj", gender = 0 };
//        obj[1] = new Customer { Name = "Samj", gender = 1 };
//        obj[2] = new Customer { Name = "Sam", gender = 2 };

//        foreach (Customer x in obj)
//        {
//            Console.WriteLine("Name= {0} &&  Gender ={1} ",x.Name,getender(x.gender));
//        }

//        Console.ReadLine();
//    }

//    public static string getender(int x)
//    {
//        switch (x)
//        {
//            case 0:
//                return "Unknown";
//            case 1:
//                return "Male";
//            case 2:
//                return "Female";
//            default:
//                return "Invalid Data";
//        }
//    }
//}

//Enum Usage here

//public enum gender
//{
//    Unknown,
//    Male,
//    Female
//}
//public class Customer
//{
//    public string Name { get; set; }
//    public gender gender { get; set; }
//}

//public class program1
//{
//    static void Main()
//    {
//        //Customer[] obj = new Customer[3];

//        //obj[0] = new Customer { Name = "Samtpj", gender = gender.Unknown};
//        //obj[1] = new Customer { Name = "Samj", gender = gender.Male };
//        //obj[2] = new Customer { Name = "Sam", gender = gender.Female };

//        //foreach (Customer x in obj)
//        //{
//        //    Console.WriteLine("Name= {0} &&  Gender ={1} ", x.Name, getender(x.gender));
//        //}

//        if (40 != 30)
//        {
//            Console.WriteLine("dw");
//        }
//        else
//        {
//            Console.WriteLine("ELSE ONE");
//        }

//        Console.ReadLine();
//    }
//}
////    public static string getender(gender gen)
////    {
////        switch (gen)
////        {
////            case gender.Unknown:
////                return "Unknown";
////            case gender.Male:
////                return "Male";
////            case gender.Female:
////                return "Female";
////            default:
////                return "Invalid Data";
////        }
////    }
////}

////changing the undelying type to short from integer
//public enum gender:short
//{
//    //you can change the values which your Enum carries
//    unkown =1,
//    male,
//    Female
//}

//public class MoreonEnums
//{
//    public static void Main()
//    {
//        //to get the symbolic values of your enum carries
//      short[] vale=  (short[])Enum.GetValues(typeof(gender));
//      foreach (short x in vale)
//      {
//          Console.WriteLine(x);
//      }
//      string[] names = Enum.GetNames(typeof(gender));
//      foreach (string x in names)
//      {
//          Console.WriteLine(x);
//      }

//        //to get the symbolic names of enum carries
//      Console.ReadLine();
//    }
//}

//

//public enum MyEnum : int
//{
//    Foo = 1,
//    Bar = 2,
//    Mek = 5
//}
//public class ke{
//static void Main(string[] args)
//{
//    var e1 = (MyEnum)5;
//    var e2 = (MyEnum)6;

//    Console.WriteLine("{0} {1}", e1, e2);
//    Console.ReadLine();
//}
////}
//public enum gender
//{
//    //you can change the values which your Enum carries
//    unkown =1,
//    male=5,
//    Female=3
//}

//public class mm
//{
//    static void Main()
//    {
//        //taking the value from the enum and showing the correspondin name
//        gender mm = (gender)3;
//        Console.WriteLine(mm);
//        //taking the value by using the male
//        int un = (int)gender.male;

//        Console.WriteLine(un);
//     Console.ReadLine();

//    }
//}

//using System;
//public enum animal
//{
//    #region fields
//    cat,
//    dog,
//    pigeon
//    #endregion
//}
//public enum gender
//{
//    unkown,
//    male,
//    female

//}

//public class kk
//{
//    static void Main()
//    {
//        animal xy = (animal)gender.male;
//        Console.WriteLine(xy);

//        Console.ReadLine();
//    }

//}

//Internal
//Check A1 project for internal fields
//public class pro:Program
//{
//    static void Main() {
//        pro obj = new pro();
//        Console.WriteLine(obj.ID);

//        Program obh1 = new Program();
//    }

//}

// Attributes and Obsolete use: obsolete is used to tell that the program is outdated or gives indication abt the pgm

//public class calculator
//{
//    //not a better way
//    //if you say true here it will throw an error, if you didn't use it will just give the warning
//    [Obsolete("please use the list<int> method")]

//    //[Obsolete("please use the list<int> method",true)]
//    public static int print(int x, int y)
//    {
//        return x + y;

//    }
//    public static int print(int x, int y,int z)
//    {
//        return x + y+z;

//    }

//    //it can add any numbers of numbers,better way

//    public static int print(List<int> numbers)
//    {
//        int sum = 0;
//        foreach (int x in numbers)
//        {
//            sum = sum + x;
//        }
//        return sum;
//    }

//}
//public class op
//{
//    static void Main()
//    {
//        calculator.print(2, 2);
//        calculator.print(new List<int>() { 2,3,2,3,2,3});

//    }
//}

//Reflications

//namespace reflection {
//    public class main
//    {
//        static void Main()
//        {
//            //gets the type of the class which contains all the info of memebers of the class
//            //Type t = Type.GetType("reflection.customer");
//            //Another way
//            //Type t = typeof(customer);
//            //Another way
//            customer obj = new customer();
//           Type t = obj.GetType();

//            Console.WriteLine("Just the Name={0}",t.FullName);
//            Console.WriteLine("Just the NameSpace={0}", t.Namespace);

//            Console.WriteLine("Properities in customer class");
//           PropertyInfo[] properties = t.GetProperties();
//           foreach (PropertyInfo property in properties)
//           {
//               Console.WriteLine(property.PropertyType.Name+" "+property.Name);
//           }

//           Console.WriteLine("Methods in customer class");
//           MethodInfo[] methods = t.GetMethods();
//           foreach (MethodInfo method in methods)
//           {
//               Console.WriteLine(method.ReturnType + " " + method.Name);
//           }

//           Console.WriteLine("Cosntructors in customer class");
//           ConstructorInfo[] consructors = t.GetConstructors();
//           foreach(ConstructorInfo cons in consructors)
//           {
//               Console.WriteLine(cons.Name);
//               Console.WriteLine(cons.ToString());

//           }

//               Console.ReadLine();
//        }

//    }
//public class customer
//{
//    public int ID { get; set; }
//    public string Name { get;set; }

//    public customer()
//    {
//        this.ID = -1;
//        this.Name = "san";
//    }

//    public customer(int id, string name)
//    {
//        this.ID = id;
//        this.Name = name;
//    }

//    public void printID()
//    {
//        Console.WriteLine("ID={0}",this.ID);
//    }

//    public void printName()
//    {
//        Console.WriteLine("Name={0}", this.Name);
//    }

//}

//}

//Early Binding

//namespace reflection
//{
//    public class main
//    {
//        static void Main()
//        {
//            customer obj = new customer();
//            obj.printName("hloo");
//            Console.ReadLine();
//        }

//    }
//    public class customer
//    {
//        public void printName(string name)
//        {
//            Console.WriteLine("Name={0}", name);
//        }

//    }

//}

//Late Binding

//namespace reflection
//{
//    public class main
//    {
//        static void Main()
//        {
//            Assembly exectuableAssembly = Assembly.GetExecutingAssembly();
//            Type t = Type.GetType("reflection.customer");
//            object customerInstance = Activator.CreateInstance(t);
//          MethodInfo methodinfo =  t.GetMethod("printName");
//          string[] parm = new string[1];
//          parm[0] = "para";

//        string fullname= (string)  methodinfo.Invoke(customerInstance, parm);
//        Console.WriteLine(fullname);
//        Console.ReadLine();
//        }

//    }
//    public class customer
//    {
//        public void printName(string name)
//        {
//            Console.WriteLine("Name={0}", name);
//        }

//    }

//}

//Gerics

public class cgenrics<T>
{
    //without generics
    //public static bool checkint(int x, int y)
    //{
    //    return x == y;
    //}

    //with object
    //public static bool checkint(object x, object y)
    //{
    //    return x == y;
    //}

    //with generic, making method generic
    //public static bool checkint<T>(T value1, T value2)
    //{
    //    return value1.Equals(value2);
    //}

    //Making class generic
    //    public static bool checkint(T value1, T value2)
    //    {
    //        return value1.Equals(value2);
    //    }

    //    private static void Main()
    //    {
    //        //cgenrics obj = new cgenrics();
    //        //cgenrics.checkint(3,3);
    //        //object event take the string and gives the result, coz other datatype inherit from the objects directly or indirectly
    //        //The below is wrong here, So thats why we nee to go for generics
    //        //Object even cost us performance, by boxing and unboxing

    //        //for the methods
    //        //bool check =   cgenrics.checkint<int>(3, 3);
    //        //bool check1 = cgenrics.checkint<string>("heloo", "world");

    //        //for the class
    //        bool check = cgenrics<int>.checkint(3, 3);
    //        bool check1 = cgenrics<string>.checkint("heloo", "world");

    //        if (check)
    //        {
    //            Console.WriteLine("Equal");
    //        }
    //        else
    //        {
    //            Console.WriteLine("Not equal");
    //        }
    //        Console.ReadLine();
    //    }
    //}
}

//public class stringch
//{
//    static void Main()
//    {
//        int x = 2;
//        Console.WriteLine(x.ToString());
//        customer c1 = new customer();
//        c1.id = 1;
//        c1.name = "sda";

//        string resule = c1.ToString();
//        Console.WriteLine(resule);
//        Console.ReadLine();
//    }
//}

//public class customer
//{
//    public string name { get; set; }
//    public int id { get; set; }

//    public override string ToString()
//    {
//        return this.name + ", " + this.id;
//    }

//}

//Equals

//public class checkeequal
//{
//    private static void Main()
//    {
//        //checking with integer
//        //int i = 3;
//        //int j = 2;
//        //Console.WriteLine(i == j);
//        //Console.WriteLine(i.Equals(j));

//        //checking with Enum
//        //Enums are value type

//        //direction direction1 = direction.east;
//        //direction direction2 = direction.east;
//        //Console.WriteLine(direction1 == direction2);
//        //Console.WriteLine(direction1.Equals(direction2));

//        //using Class
//        customer obj1 = new customer();
//        obj1.FName = "san";
//        obj1.Lname = "chavan";

//        //It will true bcoz the reference will point to the same object
//        //customer obj3 = obj1;
//        //Console.WriteLine(obj1==obj3);
//        //Console.WriteLine(obj1.Equals(obj3));
//        //It will be false coz they are two different reference, but the fname, lname as the same name but still it will show false, to correct will override it below
//        //customer obj2 = new customer();
//        //obj2.FName = "san";
//        //obj2.Lname = "chavan";
//        //Console.WriteLine(obj1==obj2);
//        //Console.WriteLine(obj1.Equals(obj2));

//        customer obj2 = new customer();
//        obj2.FName = "san";
//        obj2.Lname = "chavan";
//        Console.WriteLine(obj1 == obj2);
//        Console.WriteLine(obj1.Equals(obj2));

//        //To get rid of the swigly line, add even ovveride method of hashcode

//        Console.ReadLine();
//    }

//}

//public class customer
//{
//    public string FName{ get; set; }
//    public string Lname{ get; set; }

//      public override bool Equals(object obj)
//    {
//        if (obj == null)
//        {
//            return false;
//        }
//         if (!(obj is customer)) {
//            return false;
//        }

//          return  this.FName==((customer)obj).FName && this.Lname==((customer)obj).Lname;

//    }

//      public override int GetHashCode()
//      {
//          return this.FName.GetHashCode() ^ this.Lname.GetHashCode();
//      }
//}

//public enum direction
//{
//    east = 1,
//    west = 2,
//    north = 3,
//    south = 4
//}

//Defference between Tostring and Convert.Tostring

//public class mani
//{
//    static void Main(){
//        customer obj =null;
//        //It will not through any arrary, converts in to empty string
//       Console.WriteLine(Convert.ToString(obj));
//        //It throghs an null exception
////        Console.WriteLine(obj.ToString());

//    }

//}

//    public class customer
//{
//}

//String VS stringBuilder

//public class str
//{
//    static void Main()
//    {
//        string usersrting = "C#";
//        usersrting += "video";
//        usersrting += "tutorial ";
//        usersrting += "practise";

//        Console.WriteLine(usersrting);

//        //string Biulder

//        StringBuilder usersrting2 = new StringBuilder("C#");
//        usersrting2.Append("Video ");
//        usersrting2.Append("tutorial ");
//        usersrting2.Append("practise ");
//        Console.WriteLine(usersrting2);
//        Console.ReadLine();

//    }

//    }

//Partial Class

//namespace partialclass
//{
//    public interface Icustomer
//    {
//        void cutomername();
//    }
//    public interface Iemployee
//    {
//        void employeename();
//    }
//    public class customer
//    {
//        private string _Firstname;
//        private string _Lastname;

//        public string Lastname
//        {
//            get { return _Lastname; }
//            set { _Lastname = value; }
//        }

//        public string Firstname
//        {
//            get { return _Firstname; }
//            set { _Firstname = value; }
//        }

//        public string Fullname()
//        {
//            return _Firstname + " " + _Lastname;
//        }

//    }

//   public partial class  partialcustomer1 : Icustomer
//    {
//        private string _Firstname;
//        private string _Lastname;

//        public string Lastname
//        {
//            get { return _Lastname; }
//            set { _Lastname = value; }
//        }

//        public string Firstname
//        {
//            get { return _Firstname; }
//            set { _Firstname = value; }
//        }

//        partial void checkpartialmethod();

//    }

//  public partial class partialcustomer1:Iemployee
//  {
//      public void cutomername()
//      {
//      }
//      public void employeename()
//      {
//      }
//        public string Fullname()
//        {
//            return _Firstname + " " + _Lastname;
//        }
//        partial void checkpartialmethod()
//        {
//            Console.WriteLine("partial method is called");
//        }
//        public void partialmetho()
//        {
//            Console.WriteLine("hellow owro");
//            checkpartialmethod();
//        }

//    }

//  public partial class partialmethod
//  {
//      partial void checkpartialmethod();
//      partial void checkpartialmethod()
//      {
//          Console.WriteLine("partial method is called");
//      }
//      public void partialmetho()
//      {
//         Console.WriteLine("hellow owro");
//         checkpartialmethod();
//      }

//  }

//  public class program
//  {
//      static void Main() {
//      //customer obj = new customer();
//      //obj.Firstname = "santo";
//      //obj.Lastname = "chavan";
//      //string getname = obj.Fullname();
//      //Console.WriteLine(getname);

//          partialcustomer1 obj2 = new partialcustomer1();
//          obj2.Firstname = "rahul";
//          obj2.Lastname = "cjm";
//          obj2.partialmetho();
//          string getnae = obj2.Fullname();
//          Console.WriteLine(getnae);

//          partialmethod obj = new partialmethod();
//          obj.partialmetho();
//          Console.ReadLine();

//      }

//  }

//}

//Indexers

//public class employee
//{
//    public int id { get; set; }
//    public string name{ get; set; }
//    public string city{ get; set; }

//}

//public class company
//{
//    private List<employee> listemp;

//    public company(){
//        listemp = new List<employee>();
//        listemp.Add(new employee() { id = 1, name = "santosh", city = "hyderabad" });
//        listemp.Add(new employee() { id = 2, name = "santosh1", city = "kent" });
//        listemp.Add(new employee() { id = 3, name = "santosh2", city = "washington Dc" });
//        listemp.Add(new employee() { id = 4, name = "santosh1", city = "kent" });
//        listemp.Add(new employee() { id = 5, name = "santosh2", city = "washington Dc" });
//        listemp.Add(new employee() { id = 6, name = "santosh1", city = "kent" });
//        listemp.Add(new employee() { id = 7, name = "santosh2", city = "washington Dc" });

//}

//    public string this[int id]
//    {
//        get
//        {
//            return listemp.FirstOrDefault(emp => emp.id == id).name;
//        }
//        set
//        {
//            listemp.FirstOrDefault(emp => emp.id == id).name=value;
//        }

//    }

//    public string this[string city]
//    {
//        get {
//            return listemp.Count(emp => emp.city == city).ToString();
//        }
//        set {
//            foreach (employee emp in listemp)
//            {
//                if (emp.city == city)
//                {
//                    emp.city = value;
//                }

//            }

//        }

//    }

//}

//public class program
//{
//    static void Main(){
//    company obj = new company();
//    Console.WriteLine("the ID is "+obj[2]);
//    obj[2] = "kamine";
//    Console.WriteLine("the ID is " + obj[2]);
//    Console.WriteLine("Hyderbad counts are"+obj["hyderabad"]);
//    Console.WriteLine("kent counts are" + obj["kent"]);

//    obj["kent"] = "hyderabad";
//    Console.WriteLine("After the update of Hyderbad counts are" + obj["hyderabad"]);
//    Console.WriteLine("kent counts are" + obj["kent"]);

//    Console.ReadLine();
//    }
//}

//Dictionary

//public class customer
//{
//    public int id { get; set; }
//    public string Name { get; set; }
//    public int salary { get; set; }

//}

//public class program
//{
//    static void Main()
//    {
//        customer obj1 = new customer { id = 101, Name = "santoh", salary = 2000 };
//        customer obj2 = new customer { id = 102, Name = "santoh2", salary = 3000 };
//        customer obj3 = new customer { id = 103, Name = "santoh3", salary = 4000 };
//        customer obj4 = new customer { id = 101, Name = "santoh4", salary = 5000 };

//        Dictionary<int, customer> dicobj = new Dictionary<int, customer>();
//        dicobj.Add(obj1.id, obj1);
//        dicobj.Add(obj2.id, obj2);
//        dicobj.Add(obj3.id, obj3);
//        //To check weither the key contains are not ifit's then it wont add
//        if (!(dicobj.ContainsKey(obj4.id)))
//        {
//            dicobj.Add(obj4.id, obj4);

//        }

//        customer getvaluefocustomer = dicobj[101];
//        //Console.WriteLine("ID={0},Name={1},Salary={2}",getvaluefocustomer.id,getvaluefocustomer.Name,getvaluefocustomer.salary);

//        //To loop to the dictinoanry we need to loop through using keyvaluepair because dictionary is not just collection, but of keys and collections

//        //using var we can loop but it will not clear code to understands whats happening, better use keyvaluepair
//        //  foreach (var dictionayloop in dicobj)
//        foreach (KeyValuePair<int, customer> dictionayloop in dicobj)
//        {
//            Console.WriteLine("Key or ID ={0}", dictionayloop.Key);
//            //Here value return customer obj, so thats we are storing in customer variable
//            customer loopvalue = dictionayloop.Value;
//            Console.WriteLine("ID={0},Name={1},Salary={2}", loopvalue.id, loopvalue.Name, loopvalue.salary);
//            Console.WriteLine("----------------------------------------------------------------------------");

//        }

//        //To access only "keys"

//        foreach (int onlyKeys in dicobj.Keys)
//        {
//            Console.WriteLine(onlyKeys);
//        }

//        //To access only values
//        foreach (customer onlyvalues in dicobj.Values)
//        {
//            Console.WriteLine("ID={0},Name={1},Salary={2}", onlyvalues.id, onlyvalues.Name, onlyvalues.salary);

//        }

//        //To check weithere the value contains for particular "ID"
//        if (dicobj.ContainsKey(105))
//        {
//            customer cust = dicobj[105];
//        }

//        //Using Trygetvalues help us to check the key value if its not present it will handle the exception

//        customer checktrygetvalue;
//        if (dicobj.TryGetValue(111, out checktrygetvalue))
//        {
//            Console.WriteLine("ID={0},Name={1},Salary={2}", checktrygetvalue.id, checktrygetvalue.Name, checktrygetvalue.salary);
//        }
//        else
//        {
//            Console.WriteLine("The key is not present");
//        }

//        //Count Property
//        Console.WriteLine("Total Customers are ={0}", dicobj.Count);

//        //Count Function
//        //Its a comes from linq, Count function retruns here keyvalue pair
//        Console.WriteLine("Total Customers are ={0}", dicobj.Count(kvp => kvp.Value.salary > 2000));
//        //Removes the particular id values
//        //dicobj.Remove(101);
//        ////Removes all the key and value of dictionary
//        //dicobj.Clear();

//        //Converting Array to dictionay

//        Console.WriteLine("Converting array in to dictinoary");
//        customer[] aray = new customer[3];
//        aray[0] = obj1;
//        aray[1] = obj2;
//        aray[2] = obj3;
//        Dictionary<int, customer> convertinarraytodic = aray.ToDictionary(kvp => kvp.id, kvp => kvp);
//        foreach (KeyValuePair<int, customer> chec in convertinarraytodic)
//        {
//            Console.WriteLine(chec.Key);
//            customer temp;
//            temp = chec.Value;
//            Console.WriteLine("ID={0},Name={1},Salary={2}", temp.id, temp.Name, temp.salary);

//            //Converting list to dictionay

//            Console.WriteLine("Converting list  in to dictinoary");
//            List<customer> listobj = new List<customer>();

//            listobj.Add(obj1);
//            listobj.Add(obj2);
//            listobj.Add(obj3);

//            Dictionary<int, customer> convertinarraytodic1 = aray.ToDictionary(kvp => kvp.id, kvp => kvp);
//            foreach (KeyValuePair<int, customer> chec1 in convertinarraytodic)
//            {
//                Console.WriteLine(chec.Key);
//                customer temp1;
//                temp1 = chec.Value;
//                Console.WriteLine("ID={0},Name={1},Salary={2}", temp1.id, temp1.Name, temp1.salary);

//            }

//        }

//    }
//}

//List

//public class customer
//{
//    public int id { get; set; }
//    public string Name { get; set; }
//    public int salary { get; set; }
//}

//public class savingaccount : customer
//{
//    public int sid { get; set; }
//    public int ssalary { get; set; }
//    public string sname { get; set; }
//}

//public class program
//{
//    private static void Main()
//    {
//        customer obj1 = new customer { id = 101, Name = "santoh", salary = 2000 };
//        customer obj2 = new customer { id = 102, Name = "santoh2", salary = 3000 };
//        customer obj3 = new customer { id = 103, Name = "santoh3", salary = 4000 };
//        customer obj4 = new customer { id = 101, Name = "santoh4", salary = 5000 };

//        List<customer> listcustmr = new List<customer>(2) { new customer { id = 103, Name = "rahul", salary = 9000 } };
//        listcustmr.Add(obj1);
//        listcustmr.Add(obj2);
//        listcustmr.Add(obj3);
//        listcustmr.Add(obj4);
//        listcustmr.Insert(0, obj3);

//        List<savingaccount> savinglist = new List<savingaccount>(){
//            new savingaccount{sid=101,sname="rahlu",ssalary=89},
//              new savingaccount{sid=102,sname="rahlu",ssalary=89},
//  new savingaccount{sid=103,sname="rahlu",ssalary=89}
//        };

//        //customer listc=  listcustmr[0];
//        //Console.WriteLine("ID={0},Name={1},Salary={2}", listc.id, listc.Name, listc.salary);

//        //for (int i = 0; i < listcustmr.Count; i++)
//        //{
//        //    customer c = listcustmr[i];
//        //    Console.WriteLine("ID={0},Name={1},Salary={2}", c.id, c.Name, c.salary );
//        //}

//        //foreach (customer c in listcustmr)
//        //{
//        //    Console.WriteLine("ID={0},Name={1},Salary={2}", c.id, c.Name, c.salary);

//        //}

//        //Index of gives the first index of occurance, second paramter statrs the index from 1 index, the third parameter is used for the last index to check
//        //Console.WriteLine(listcustmr.IndexOf(obj3,1,3));

//        // you can add inherited class in the class
//        //savingaccount savingact = new savingaccount();
//        //listcustmr.Add(savingact);

//        //Contains checks and returns true or false

//        //if (listcustmr.Contains(obj1))
//        //{
//        //    Console.WriteLine("the value is contain in the list");
//        //}
//        //else
//        //{
//        //    Console.WriteLine("No value found");
//        //}

//        //Exists checks with the condition and returns the true and false value
//        //if (listcustmr.Exists(cust => cust.Name.StartsWith("r")))
//        //{
//        //    Console.WriteLine("The customer name starts from \"R conatins in the list");
//        //}
//        //else
//        //{
//        //    Console.WriteLine("No value found");
//        //}

//        //Find: It searches using lambda and it just returns only one value, the first value

//        customer ca = listcustmr.Find(cus => cus.salary > 2000);
//        Console.WriteLine("ID={0},Name={1},Salary={2}", ca.id, ca.Name, ca.salary);

//        //FindLast: It searches using lambda and it just returns only one value, the last value

//        customer la = listcustmr.FindLast(cus => cus.salary > 2000);
//        Console.WriteLine("ID={0},Name={1},Salary={2}", la.id, la.Name, la.salary);

//        //Findall: It search and return all the values
//        List<customer> fa = listcustmr.FindAll(cus => cus.salary > 2000);
//        foreach (customer fa1 in fa)
//        {
//            Console.WriteLine("ID={0},Name={1},Salary={2}", fa1.id, fa1.Name, fa1.salary);
//        }

//        //findIndex : search and returns the first matched index, on integer form

//        int index = listcustmr.FindIndex(2, 3, custr => custr.salary > 2000);
//        Console.WriteLine("index " + index);
//        //findLastIndex : search and returns the first matched index, on integer form

//        int indexlast = listcustmr.FindLastIndex(2, 3, custr => custr.salary > 2000);
//        Console.WriteLine("indexLast " + indexlast);

//        //Converting array in to the list

//        customer[] custmerArray = new customer[3];
//        custmerArray[0] = obj1;
//        custmerArray[1] = obj2;
//        custmerArray[2] = obj3;

//     List<customer> listfoarray=   custmerArray.ToList();
//     foreach (customer c in listfoarray)
//     {
//         Console.WriteLine("ID={0},Name={1},Salary={2}", c.id, c.Name, c.salary);

//     }

//        //Converting list to array

//     List<customer> listtoarray = new List<customer>(){
//            new customer{id=105,Name="prit",salary=4000},
//            new customer{id=106,Name="prit",salary=5000},
//new customer{id=104,Name="prit",salary=6000}

//        };

//    customer[] customerloop= listtoarray.ToArray();
//    foreach (customer c in customerloop)
//    {
//        Console.WriteLine("ID={0},Name={1},Salary={2}", c.id, c.Name, c.salary);

//    }

//        //Converting list to a dictionary
//        //
//   Dictionary<int,customer> listdic = listtoarray.ToDictionary(cus => cus.id);
//   foreach (KeyValuePair<int,customer> c in listdic)
//   {
//       Console.WriteLine("Id={0}",c.Key);
//       customer ma = c.Value;
//       Console.WriteLine("Dicitinoary to list ID={0},Name={1},Salary={2}", ma.id, ma.Name, ma.salary);

//   }

//    }
//}

//Add range in list


//public class customer
//{
//    public int id { get; set; }
//    public string Name { get; set; }
//    public int salary { get; set; }
//    public string type { get; set; }
//}


//public class program
//{
//    private static void Main()
//    {
//        customer obj1 = new customer { id = 101, Name = "santoh", salary = 2000 ,type="current Account"};
//        customer obj2 = new customer { id = 102, Name = "santoh2", salary = 3000, type = "current Account" };
//        customer obj3 = new customer { id = 103, Name = "santoh3", salary = 4000, type="saving Account"};
//        customer obj4 = new customer { id = 104, Name = "santoh4", salary = 5000 ,type="saving Account"};

     
//       List<customer> listcus = new List<customer>();
//       listcus.Add(obj1);
//       listcus.Add(obj2);
//       List<customer> savinglistcus = new List<customer>();
//       savinglistcus.Add(obj3);
//       savinglistcus.Add(obj4);
       

//        //Adding saving account data in customer
//       //listcus.AddRange(savinglistcus);
//        //Insert range
//       listcus.InsertRange(0, savinglistcus);
//       listcus.Remove(obj4);
//       listcus.RemoveAt(3);
//       listcus.RemoveAll(x => x.salary > 4000);
//       listcus.RemoveRange(2, 5);

//       foreach (customer c in listcus)
//       {
//           Console.WriteLine(" ID={0},Name={1},Salary={2},Type={3}", c.id, c.Name, c.salary,c.type);          
//       }


//   }
//}


//List Sort

//public class sorting
//{

//    static void Main()
//    {
//        List<int> x = new List<int>() { 2, 1, 4, 5, 2, 21, 212, 1 };
//        foreach (int y in x)
//        {
//            Console.WriteLine(y+" ");
//        }
//        x.Sort();
//        Console.WriteLine("After the sorting");
//        foreach (int z in x)
//        {
//            Console.WriteLine(z+" ");

//        }

//        x.Reverse();
//        Console.WriteLine("Sorting the list in descending order");
//        foreach (int z in x)
//        {
//            Console.WriteLine(z + " ");

//        }


//        List<string> alphabets = new List<string>() {"a","b","d","h","e","p" };

//        foreach (string alphabet in alphabets)
//        {
//            Console.WriteLine(alphabet + " ");

//        }
//        alphabets.Sort();

//        Console.WriteLine("Sorting the list");
//        foreach (string alphabet in alphabets)
//        {
//            Console.WriteLine(alphabet + " ");

//        }
//        alphabets.Reverse();
//        Console.WriteLine("Sorting the list in descending order");

//        foreach (string alphabet in alphabets)
//        {
//            Console.WriteLine(alphabet + " ");

//        }





//    }

//}



//List sort for Complex types

//public class customer : IComparable<customer>
//{
    //public int id { get; set; }
    //public string Name { get; set; }
    //public int salary { get; set; }
    //public string type { get; set; }

    //public int CompareTo(customer other)
    //{
    //    if (this.salary > other.salary)
    //    {
    //        return 1;
    //    }
    //    else if (this.salary < other.salary) {
    //        return -1;
    //    }else
    //    {
    //        return 0;
    //    }
    //}

    //Another method to sort
    //Sorting salary
    //public int CompareTo(customer other)
    //{
    //    return this.salary.CompareTo(other.salary);
    //}
    //  Sorting by name
    //    public int CompareTo(customer other)
    //    {
    //        return this.Name.CompareTo(other.Name);
    //    }



    //}

    //public class sortbyname : IComparer<customer>
    //{
    //    //Another method which is manually created

    //    public int Compare(customer x, customer y)
    //    {
    //        return x.Name.CompareTo(y.Name);
    //    }
    //}


    //public class program
    //{
    //    private static void Main()
    //    {
    //        customer obj1 = new customer { id = 101, Name = "santoh32", salary = 8000 ,type="current Account"};
    //        customer obj2 = new customer { id = 102, Name = "santoh23", salary = 13000, type = "current Account" };
    //        customer obj3 = new customer { id = 103, Name = "santoh3", salary = 4000, type="saving Account"};
    //        customer obj4 = new customer { id = 104, Name = "santoh4", salary = 300 ,type="saving Account"};


    //       List<customer> listcus = new List<customer>();
    //       listcus.Add(obj1);
    //       listcus.Add(obj2);
    //       listcus.Add(obj3);
    //       listcus.Add(obj4);
    //       Console.WriteLine("Before sorting");
    //       foreach (customer c in listcus)
    //       {
    //           Console.WriteLine(c.salary);
    //       }
    //       Console.WriteLine("after sorting");
    //        listcus.Sort();
    //        foreach (customer c in listcus)
    //        {
    //            Console.WriteLine(c.salary);
    //        }

    //        //Sorting for names
    //        foreach (customer c in listcus)
    //        {
    //            Console.WriteLine(c.Name);
    //        }

    //        //Manually sort the customer by name
    //        Console.WriteLine("manual sorting");
    //        sortbyname objsotbyname = new sortbyname();
    //        listcus.Sort(objsotbyname);
    //        foreach (customer c in listcus)
    //        {
    //            Console.WriteLine(c.Name);
    //        }

    //    }
    //}

    //Delegate in list sorts
    //public class customer {
    //    public int id { get; set; }
    //    public string Name { get; set; }
    //    public int salary { get; set; }
    //    public string type { get; set; }
    //}
    //public class program
    //{
    //    private static void Main()
    //    {
    //        customer obj1 = new customer { id = 101, Name = "santoh32", salary = 8000, type = "current Account" };
    //        customer obj2 = new customer { id = 108, Name = "santoh23", salary = 13000, type = "current Account" };
    //        customer obj3 = new customer { id = 101, Name = "santoh3", salary = 4000, type = "saving Account" };
    //        customer obj4 = new customer { id = 103, Name = "santoh4", salary = 300, type = "saving Account" };


    //        List<customer> listcus = new List<customer>();
    //        listcus.Add(obj1);
    //        listcus.Add(obj2);
    //        listcus.Add(obj3);
    //        listcus.Add(obj4);
    //        Console.WriteLine("Before sorting");
    //        foreach (customer c in listcus)
    //        {
    //            Console.WriteLine(c.id);
    //        }
    //        Console.WriteLine("After sorting wth delegate for ID");
           
           

    //        Comparison<customer> compobj = new Comparison<customer>(Comparisoncustimer);
    //        listcus.Sort(compobj);
    //        foreach (customer c in listcus)
    //        {
    //            Console.WriteLine(c.id);
    //        }

    //    }
    //    private static int Comparisoncustimer(customer x, customer y)
    //    {
    //        return x.id.CompareTo(y.id);
    //    }
    //}

// Anothe way of using delegate keyword, remove function, remove delegate instance
    //public class customer
    //{
    //    public int id { get; set; }
    //    public string Name { get; set; }
    //    public int salary { get; set; }
    //    public string type { get; set; }
    //}
    //public class program
    //{
    //    private static void Main()
    //    {
    //        customer obj1 = new customer { id = 101, Name = "santoh32", salary = 8000, type = "current Account" };
    //        customer obj2 = new customer { id = 108, Name = "santoh23", salary = 13000, type = "current Account" };
    //        customer obj3 = new customer { id = 101, Name = "santoh3", salary = 4000, type = "saving Account" };
    //        customer obj4 = new customer { id = 103, Name = "santoh4", salary = 300, type = "saving Account" };


    //        List<customer> listcus = new List<customer>();
    //        listcus.Add(obj1);
    //        listcus.Add(obj2);
    //        listcus.Add(obj3);
    //        listcus.Add(obj4);
    //        Console.WriteLine("Before sorting");
    //        foreach (customer c in listcus)
    //        {
    //            Console.WriteLine(c.id);
    //        }
    //        Console.WriteLine("After sorting wth delegate for ID");




    //        //listcus.Sort(delegate(customer x, customer y)
    //        //{
    //        //    return x.id.CompareTo(y.id);

    //        //});


    //    listcus.Sort((x,y)=>x.id.CompareTo(y.id));

    //        foreach (customer c in listcus)
    //        {
    //            Console.WriteLine(c.id);
    //        }

    //    }
      
    //}

//Useful methods of list
    //public class customer
    //{
    //    public int id { get; set; }
    //    public string Name { get; set; }
    //    public int salary { get; set; }
    //    public string type { get; set; }
    //}
    //public class program
    //{
    //    private static void Main()
    //    {
    //        customer obj1 = new customer { id = 101, Name = "santoh32", salary = 8000, type = "current Account" };
    //        customer obj2 = new customer { id = 108, Name = "santoh23", salary = 13000, type = "current Account" };
    //        customer obj3 = new customer { id = 101, Name = "santoh3", salary = 4000, type = "saving Account" };
    //        customer obj4 = new customer { id = 103, Name = "santoh4", salary = 300, type = "saving Account" };


    //        List<customer> listcus = new List<customer>(100);
    //        listcus.Add(obj1);
    //        listcus.Add(obj2);
    //        listcus.Add(obj3);
    //        listcus.Add(obj4);
    //        Console.WriteLine("Before sorting");
    //        foreach (customer c in listcus)
    //        {
    //            Console.WriteLine(c.salary);
    //        }

    //        //TureForall
    //        //bool val = listcus.TrueForAll(x => x.salary > 300);
    //        //Console.WriteLine("The salary is greater then 300 for all the employess is "+val);

    //        //AsReadOnly
    //    ReadOnlyCollection<customer> readonlyobj =    listcus.AsReadOnly();
    //    Console.WriteLine("Items"+readonlyobj.Count);
        
    //        //Trim 
    //    Console.WriteLine("Trim Befor ={0}", listcus.Capacity);

    //    listcus.TrimExcess();

    //    Console.WriteLine("Trim After ={0}",listcus.Capacity);

               


    //    }

    //}

//  When to use dictionay over List

//public class customer
//{
//    public int id { get; set; }
//    public string Name { get; set; }
//    public int salary { get; set; }
//    public string code { get; set; }
//}
//public class program
//{
//    private static void Main()
//    {
//        customer obj1 = new customer { id = 101,  Name = "AUSTRAILA", salary = 8000, code = "AUS" };
//        customer obj2 = new customer { id = 108, Name = "ENGLAND", salary = 13000, code = "ENG" };
//        customer obj3 = new customer { id = 101, Name = "UNITED STATES", salary = 4000, code = "USA" };
//        customer obj4 = new customer { id = 103, Name = "INDIA", salary = 300, code = "IND" };


//        List<customer> listcus = new List<customer>(100);
//        listcus.Add(obj1);
//        listcus.Add(obj2);
//        listcus.Add(obj3);
//        listcus.Add(obj4);

//        string chechyes =string.Empty;
//        do
//        {
//            Console.WriteLine("Please enter the code for the Country");
//            string usercode = Console.ReadLine().ToUpper();
//            customer obj = listcus.Find(x => x.code == usercode);
//            if (obj == null)
//            {
//                Console.WriteLine("Please Enter the valide code");
//            }
//            else
//            {
//                Console.WriteLine("Name={0} ", obj.Name);
//            }

//            do
//            {
//                Console.WriteLine("Do you want to continue YES OR NO");
//                chechyes = Console.ReadLine().ToUpper();
//            } while (chechyes != "YES" & chechyes != "NO");

//        } while (chechyes == "YES");
//        }
//}

//disadvantage of using list is: Find() method of the list class loop thru each object in list untill a match is found.
//For the better performance use dictionay
//using Dictinoary

public class customer
{
    public int id { get; set; }
    public string Name { get; set; }
    public int salary { get; set; }
    public string code { get; set; }
}
public class program
{
    private static void Main()
    {
        customer obj1 = new customer { id = 101, Name = "AUSTRAILA", salary = 8000, code = "AUS" };
        customer obj2 = new customer { id = 108, Name = "ENGLAND", salary = 13000, code = "ENG" };
        customer obj3 = new customer { id = 101, Name = "UNITED STATES", salary = 4000, code = "USA" };
        customer obj4 = new customer { id = 103, Name = "INDIA", salary = 300, code = "IND" };


        Dictionary<string,customer> dictcus = new Dictionary<string,customer>();
        dictcus.Add(obj1.code,obj1);
        dictcus.Add(obj2.code,obj2);
        dictcus.Add(obj3.code,obj3);
        dictcus.Add(obj4.code,obj4);

        string chechyes = string.Empty;
        do
        {
            Console.WriteLine("Please enter the code for the Country");
            string usercode = Console.ReadLine().ToUpper();
            customer obj = dictcus.ContainsKey(usercode)?dictcus[usercode] : null;
            if (obj == null)
            {
                Console.WriteLine("Please Enter the valide code");
            }
            else
            {
                Console.WriteLine("Name={0} ", obj.Name);
            }

            do
            {
                Console.WriteLine("Do you want to continue YES OR NO");
                chechyes = Console.ReadLine().ToUpper();
            } while (chechyes != "YES" & chechyes != "NO");

        } while (chechyes == "YES");
    }
}





















