﻿namespace ClassLibrary
{
    public class Class1
    {
        public static string Getname1()
        {
            return "class library";
        }
    }
}