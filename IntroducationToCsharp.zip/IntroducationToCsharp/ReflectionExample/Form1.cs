﻿using System;
using System.Reflection;
using System.Windows.Forms;

namespace ReflectionExample
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string getype = textBox1.Text;
            Type t = Type.GetType(getype);

            Methods.Items.Clear();
            Properties.Items.Clear();
            Constructor.Items.Clear();


            MethodInfo[] methods = t.GetMethods();
            foreach (MethodInfo method in methods)
            {
                Methods.Items.Add(method.ReturnType.Name + " " + method.Name);
            }
            PropertyInfo[] properties = t.GetProperties();
            foreach(PropertyInfo propertie in properties)
            {
               Properties.Items.Add(propertie.PropertyType.Name + " " + propertie.Name);
            }


            ConstructorInfo[] constru = t.GetConstructors();
            foreach (ConstructorInfo constructor in constru)
            {
                Constructor.Items.Add(constructor.ToString());
            }

        }
    }
}