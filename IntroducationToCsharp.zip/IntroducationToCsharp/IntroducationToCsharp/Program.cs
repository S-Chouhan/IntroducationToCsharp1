﻿namespace IntroducationToCsharp
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            //  Console.WriteLine(ClassLibrary.Class1.Getname2());
            // Console.ReadLine();
        }
    }
}