﻿using ClassLibrary;
using System;

namespace A1
{
    public class Program
    {
       protected internal int ID = 19;

        //private static void Main(string[] args)
        //{
        //    Console.WriteLine(Class1.Getname1());
        //    Console.ReadLine();
        //}
    }


    public class checkInternal
    {
       private static void Main(string[] args)
        {
            Program obj = new Program();
            System.Console.WriteLine(obj.ID);
              Console.ReadLine();
        }

    }
}