﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DictionaryExample
{
    public class customer
    {
 public int id { get; set; }
    public string Name { get; set; }
    public int salary { get; set; }
    public string code { get; set; }
}
    }
