﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DictionaryExample
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["dictionaryValuesinsession"] == null)
            { 
            customer obj1 = new customer { id = 101, Name = "AUSTRAILA", salary = 8000, code = "AUS" };
            customer obj2 = new customer { id = 108, Name = "ENGLAND", salary = 13000, code = "ENG" };
            customer obj3 = new customer { id = 101, Name = "UNITED STATES", salary = 4000, code = "USA" };
            customer obj4 = new customer { id = 103, Name = "INDIA", salary = 300, code = "IND" };


            Dictionary<string, customer> dictcus = new Dictionary<string, customer>();
            dictcus.Add(obj1.code, obj1);
            dictcus.Add(obj2.code, obj2);
            dictcus.Add(obj3.code, obj3);
            dictcus.Add(obj4.code, obj4);

            Session["dictionaryValuesinsession"] = dictcus;
            }
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

            Dictionary<string, customer> dictinoarycountries = (Dictionary<string,customer>)Session["dictionaryValuesinsession"];

            customer obj = dictinoarycountries.ContainsKey(TextBox1.Text.ToUpper())?dictinoarycountries[TextBox1.Text.ToUpper()] : null;
            if (obj == null)
            {
                Label4.Text = "Please enter the correct code";
            }
            else
            {
                TextBox2.Text = obj.Name;
                TextBox3.Text = obj.salary.ToString();
            }

           


        }
    }
}