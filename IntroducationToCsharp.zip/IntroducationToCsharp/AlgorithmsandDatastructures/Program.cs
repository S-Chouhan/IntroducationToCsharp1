﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgorithmsandDatastructures
{
    class Program
    {
        public int value { get; set; }
        public Program node { get; set; }
        static void Main(string[] args)
        {
            Program ob1 = new Program();
            ob1.value = 1;
            Program ob2 = new Program();
            ob2.value = 2;

            ob1.node = ob2;
            Program ob3 = new Program();
            ob3.value = 3;
            ob2.node = ob3;


            
        }
    }
}
